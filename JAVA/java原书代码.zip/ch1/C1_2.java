package ch1;
import java.applet.Applet;
import java.awt.Graphics;
public  class  C1_2  extends  Applet 
{
    @Override
   public  void  paint(Graphics  g)
   {  g.drawString("Java Now!",25,25);   }
}
