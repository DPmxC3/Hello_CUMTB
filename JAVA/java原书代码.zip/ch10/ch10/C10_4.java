package ch10;
import java.awt.Container;
import java.awt.GridLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
public class C10_4 extends JApplet
{   JButton bt1=new JButton("按钮A");
    JButton bt2=new JButton("按钮B");
    Container cp=getContentPane( );
   //����GridLayout����
   GridLayout grid=new GridLayout(2,2,20,30);
    @Override
    public void init( ) 
    {  
      cp.setLayout(grid);
      cp.add(bt1);
      cp.add(bt2);
      cp.add(new JButton("按钮C"));
      cp.add(new JButton("按钮D"));

     }  
 }


