package ch10;
import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JApplet;
import javax.swing.JButton;
public class  C10_2  extends JApplet
{   Container cp=getContentPane( );
    JButton button1, button2, button3;  
    @Override
    public void init() {
        cp.setLayout(new FlowLayout());
        button1 = new JButton("Ok");
        button2 = new JButton("Open");
        button3 = new JButton("Close");
        cp.add(button1);
        cp.add(button2);
        cp.add(button3);   
   }
 }

