package ch10;
import java.awt.BorderLayout;
import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JLabel;
public class C10_6
{  
  public C10_6() {  
   //Create and set up the JFrame.       
    JFrame f = new JFrame("FrameDemo");
    f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);     
    JLabel  lb = new JLabel("这是JFrame");      
    lb.setPreferredSize(new Dimension(175, 100));   
    f.getContentPane().add(lb, BorderLayout.CENTER);       
   //Display the JFrame. 
    f.pack( );
    f.setVisible(true);    
   }    
  public static void main(String[] args) 
  {  C10_6 cc = new C10_6();	 } 
}	

