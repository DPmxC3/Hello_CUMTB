package ch10;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import javax.swing.Box;
import javax.swing.JApplet;
import javax.swing.JButton;

public class C10_52 extends JApplet{
   JButton b1=new JButton(" Top   "); 
   JButton b2=new JButton("Middle1"); 
   JButton b3=new JButton("Bottom "); 
   JButton b4=new JButton("Left "); 
   JButton b5=new JButton("Right"); 
    @Override
   public void init() {
     Container cp=getContentPane( );
     //按垂直排列
     Box vBox = Box.createVerticalBox(); 
     b1.setMaximumSize(new Dimension(200,200));  //设置按钮的最大长度
     //加入垂直透明组件Strut，间隔为20像素
     vBox.add(Box.createVerticalStrut(10)); 
     vBox.add(b1);
     vBox.add(Box.createVerticalStrut(10));
     vBox.add(b2); 
     vBox.add(b3);
     cp.add(vBox,BorderLayout.NORTH); 
     //按水平排列
     Box hBox = Box.createHorizontalBox( );     
     hBox.add(b4);
     hBox.add(Box.createHorizontalGlue( )); //加入水平透明组件Glue，组件挤到两边
     hBox.add(b5); 
     cp.add(hBox,BorderLayout.SOUTH);     
   }   
}
