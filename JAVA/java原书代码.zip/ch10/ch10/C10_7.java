package ch10;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
public class  C10_7 extends JFrame
{
    JLabel[ ] lb=new JLabel[3];  //创建标签数组
    JPanel pa1=new JPanel( );  //创建面板对象
    JPanel pa2=new JPanel(new GridLayout(1,2));
    public  C10_7( )
    {   setLayout(new GridLayout(2,1));
        for(int i=0; i<lb.length ; i++)  //设置每个标签的属性
         { lb[i]=new JLabel("标签 "+(i+1),JLabel.CENTER);
           lb[i].setBackground(Color.yellow);  //设置标签颜色
           lb[i].setBorder(BorderFactory.createEtchedBorder( ));  //设置标签边框
           lb[i].setOpaque(true);  //让组件变为不透明，使标签颜色显示出来
         }        
        pa1.add(lb[0]);  //加载第0个标签在面板上
        pa2.add(lb[1],BorderLayout.NORTH); //加载第1个标签在面板上
        pa2.add(lb[2],BorderLayout.SOUTH); //加载第2个标签在面板上
        add(pa1); //将pa1的对象添加到cc对象中
        add(pa2);
        setTitle("JPanelDemo");
        pack( );
        setVisible(true); 
    }
    public static void main(String[ ] arg)
     {    C10_7 cc=new C10_7( ); }
}
