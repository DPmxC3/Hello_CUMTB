package ch10;
import java.awt.CardLayout;
import java.awt.Container;
import javax.swing.JApplet;
import javax.swing.JButton;
public class C10_3 extends JApplet
{   JButton bt1=new JButton("按钮A");
    JButton bt2=new JButton("按钮B");
    JButton bt3=new JButton("按钮C");
    Container cp=getContentPane( );
      //����CardLayout����
    CardLayout card=new CardLayout(20,20);
    @Override
    public void init( ) 
    {  cp.setLayout(card);
       cp.add("a",bt1);
       cp.add("b",bt2);    cp.add("c",bt3);
       card.next(cp); //��ʾ��ťB
     }  
 }

