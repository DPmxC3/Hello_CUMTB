package ch10;
import java.awt.BorderLayout;
import java.awt.Container;
import javax.swing.JApplet;
import javax.swing.JButton;
public class C10_1 extends JApplet
{  Container cp=getContentPane( );
    @Override
   public void init() {
     cp.add(new JButton("North"),   BorderLayout.NORTH);
     cp.add(new JButton("South"), BorderLayout.SOUTH);
     cp.add(new JButton("East"), BorderLayout.EAST);
     cp.add(new JButton("West"), BorderLayout.WEST);
     cp.add(new JButton("Center"), BorderLayout.CENTER);
   }
}

