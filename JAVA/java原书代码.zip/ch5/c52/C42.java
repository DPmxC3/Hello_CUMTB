package c52;
import  c51.C41;
public class C42 extends C41
{
  public  static  void  main(String[ ]  args)
  { 
    double s1;
    C42 p1=new  C42();
    p1.x1=7;      //对
    s1=p1.ar(4);  //对
    // p1.x2=9; 错，不能访问
     System.out.println("p1.x1="+p1.x1+" s1="+s1);
  }  
}
