package c52;
import c51.A;
public class B{
 public  static  void  main(String[ ]  args)
  { double s1;
    A p1=new  A();  //创建A类的对象
   //  p1.x1=7; x1不是公共数据成员不能访问
    p1.x2=5.2;      //访问A类对象的数据成员
    s1=p1.ar(8);    //访问A类对象的成员方法
    System.out.println("p1.x2="+p1.x2+" s1="+s1);

  }   
}
