package c51;
public  class  A
 {
   double x1;          //友好访问的数据成员
    public double x2;   //公共的数据成员
    public  double  ar(double x)  //公共的成员方法

     {  double s;  
         s=x;
         return s;   
     }
}