package c51;
public class C41 {
  protected  double  x1; 
  double x2;
  protected  double  ar(double x)
     {  double s;  
         s=x;
         return s;   
     }
}