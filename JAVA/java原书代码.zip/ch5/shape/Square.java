package shape;
public  class  Square  extends  Coordinates  implements  Shapes
{
  public  int  width,height;
    @Override
  public  double  getArea( ){return(width*height);}
    @Override
  public  double  getPerimeter( ){return(2*width+2*height);}
  public  Square(int  x,int  y,int  width,int  height)
   { super(x,y);
     this.width=width;
     this.height=height;
   }
}
