package shape;
public interface  Shapes
{ 
  abstract double getArea( );
  abstract double getPerimeter( );
}

