package shape;
public  class  Circle  extends  Coordinates  implements  Shapes
{ public  int  width,height;
  public  double  r;
    @Override
  public  double  getArea( ){return(r*r*Math.PI);}
    @Override
  public  double  getPerimeter( ){return(2*Math.PI*r);}
  public  Circle(int  x,int  y,int  width,int  height)
    { super(x,y);
      this.width=width;
      this.height=height;
      r=(double)width/2.0;
    }
}
