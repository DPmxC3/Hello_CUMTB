package ch5;
class  A11
{  int x=8;  }     	    //父类中定义了数据成员x

class  C5_7  extends  A11   
{  int  x=24;               //子类中也定义了数据成员x
   public  static  void  main(String[ ]  argS)
   {  int  s1,s2;
      A11  p=new  A11( );  	 //创建父类p的对象
      C5_7  p1=new  C5_7( );  	//创建子类p1的对象
      s1=p.x;
      s2=p1.x;     //子类对象引用自己的数据成员，把父类数据成员“隐藏”起来
      System.out.println("s1="+s1);
      System.out.println("s2="+s2);
   }
}
