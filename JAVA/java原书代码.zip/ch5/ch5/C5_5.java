package ch5;
import java.applet.Applet;
import java.awt.Graphics;
public class C5_5 extends Applet
{ 
  int  add(int  a,int  b)    //重载的方法1
    { return(a+b);}
  double  add(double x,double y) 	//重载的方法2
    {  return(x+y); }
  double  add(double x,double y, double z) //重载的方法3
    {  return(x+y+z); }
    @Override
  public  void  paint(Graphics g)
    {
       g.drawString("Sum is:"+add(8.5,2.3),5,10);
       g.drawString("Sum is:"+add(21,38),5,30);
       g.drawString("Sum is:"+add(8.5,2.3,8.5+2.3),5,50);
    }
}
