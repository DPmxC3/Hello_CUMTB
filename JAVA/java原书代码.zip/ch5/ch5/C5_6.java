package ch5;
class  A1
{  int  x=25;
   private  int  z;         //不能被子类继承的私有数据成员z
 }
class  C5_6  extends  A1  //A1是C5_6的父类，C5_6是A1的子类
{
   public  static  void  main(String[ ] argS)
   {   C5_6  p=new  C5_6( );
       System.out.println("p.x="+p.x);  //输出继承来的数据成员的值
       //System.out.println("p.z="+p.z); 错，不能继承private修饰的z
    }
}

