package ch5;
class  Student
{  public  String  name;
   public  char   sex;
   public  int    no;
   public  int    age;
   Student(int  cno, String  cname, char  csex, int  cage)
   {  name=cname;
      sex=csex;
      no=cno;
      age=cage;
   }
   public void showNo( ){System.out.println("No:"+no);}
   public void showName( ){System.out.println("Name:"+name);}
   public void showSex( ){System.out.println("Sex:"+sex);}
   public void showAge( ){System.out.println("age:"+age);}
}
class  StudentScore
{  private  int  no;
   private  double score;
   public  void  sendScore(int cno,double cscore)
    {   //下面两条语句是对象发送给自身的消息，要求给自己的数据成员赋值， 
        //这是一种私有消息，外界是不知道的
       no=cno; 
       score=cscore;
    }
   void printScore( ){System.out.println("No:"+no+"  score:"+score);}
}      
public  class C5_1
{
   public  static  void  main(String[ ]  args)
    {   int m;
      //下面两句发送new消息给类Student，要求创建st1,st2的对象
      Student  st1=new  Student(101,"zhang li",'F',18); 
      Student  st2=new  Student(102,"hong bing",'M',17);
      //发送new消息给类StudentScore，要求创建sc1,sc2的对象
      StudentScore  sc1=new  StudentScore( ); 
      StudentScore  sc2=new  StudentScore( ); 
       /* 向st1的对象发送显示学号、名字、年龄的消息。这些消息都是公有消息。它们形成
            了同一对象可接收不同形式的多个消息，产生不同的响应*/
      st1.showNo( );  //这是一条消息，消息响应的结果是显示st1的对象的学号
      st1.showName( );  	//显示对象姓名的消息
      st1.showAge( );   	//显示对象年龄的消息
      st1.age=20;      	//修改对象的数据成员的消息，修改st1对象的年龄
      m=st1.age;     	//返回对象的数据成员的消息，将返回消息赋给变量m
      System.out.println("m="+m);
      /* 向st2的对象发送两个显示信息的消息，与st1的对象相同，显示学号及名字。这些消
        息都是公有消息，说明了相同形式的消息可以送给不同的对象，各对象所做出的响应
        可以是截然不同的*/
      st2.showNo( );
      st2.showName( );
      //向sc1、sc2的对象各发送一个按学号输入成绩单的消息，这些消息都是公有消息
      sc1.sendScore(101,97);
      sc2.sendScore(102,84);
      //向sc1、sc2的对象各发送一个打印消息，这些消息都是公有消息
      sc1.printScore( );
      sc2.printScore( );
    }
}

