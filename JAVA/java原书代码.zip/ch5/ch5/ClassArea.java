﻿package ch5;
class  ClassArea
 {
     double lon,wid;   //数据成员的修饰符为缺省
     double area(double x,double y) //成员方法的修饰符为缺省 
     {  double s;     //方法内的变量
        lon=x;
        wid=y;
        s=lon*wid;    //求矩形面积
        return s;     //返回面积值
     }
 }
