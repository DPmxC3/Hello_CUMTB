package ch5;
class  Addclass
{  
    public int x=0,y=0,z=0;
    //以下是多个同名不同参数的构造方法
    Addclass(int x)  			//可重载的构造方法1
    {   this.x=x;  }
    Addclass(int x,int y)  		//可重载的构造方法2
    {
       this(x);   			//当前构造方法调用可重载的构造方法1
       this.y=y;
    }
    Addclass(int x,int y,int z)  	//可重载的构造方法3
    {
       this(x,y);   			//当前构造方法调用可重载的构造方法2
       this.z=z;
    }
    public int add( )
    { return  x+y+z;}
 }
 public  class  C5_14
 {
    public static void main(String[ ] args)
     {
       Addclass  p1=new  Addclass(2,3,5);
       Addclass  p2=new  Addclass(10,20);
       Addclass  p3=new  Addclass(1);
       System.out.println("x+y+z="+p1.add( ));
       System.out.println("x+y="+p2.add( ));
       System.out.println("x="+p3.add( ));
     }
 }
