﻿package ch5;
class  A4
{  int  x=0;  int y=1;
   public  void  Printme( )
   {  System.out.println("x="+x+" y="+y);
      System.out.println("I am an "+this.getClass( ).getName( ));
   //用this来访问当前对象的成员方法，通过this表示当前对象，来打印当前
   //对象的类名。其中getClass( )和getName( )是系统类库中提供的方法
   }
}
public  class  C5_10  extends  A4
{
  public  static  void  main(String  arg[ ])
  { C5_10  p1=new  C5_10( );
    p1.Printme( );
  }
}

