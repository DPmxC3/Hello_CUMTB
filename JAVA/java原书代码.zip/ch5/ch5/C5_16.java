﻿package ch5;
import java.applet.Applet;
import java.awt.Graphics;
class  Student1
{  public  String  Name;
   public int age=16;   public int score=0;
   public void ShowStudent(Graphics g,int x,int y)
   { g.drawString("Name:"+Name,x,y);
     g.drawString("age:"+age,x,y+20);
     g.drawString("score:"+score,x,y+40);
   }
}

public  class  C5_16  extends  Applet
{
public  void  studentAttributes(Student1 s,String Name, int age, int score)
   {  s.Name=Name;  
      s.age=age;
      s.score=score;
   }
    @Override
   public  void  paint(Graphics g)
    { Student1  st1=new  Student1( );   	//创建st1的对象
      Student1  st2=new  Student1( );   	//创建st2的对象
      studentAttributes(st1,"zhang",23,81); 	//对象st1作为实参
      studentAttributes(st2,"li",24,90);    	//对象st2作为实参
      st1.ShowStudent(g,25,25); //执行此方法可发现st1的对象将新值带回
      st2.ShowStudent(g,25,120);//再次执行此方法可发现st2的对象将新值带回
    }
 }

