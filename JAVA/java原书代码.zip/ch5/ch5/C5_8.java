package ch5;
class  A2
{   int x=0,y=1;
    void Myp( )
     {   System.out.println("x="+x+"  y="+y); }
    private void Printme( )
     {   System.out.println("x="+x+"  y="+y); }
}

public  class  C5_8  extends  A2
{
   public  static  void  main(String  arg[ ])
     {  int  z=3;
        C5_8  p1=new  C5_8( );
        p1.Myp( );
        // p1.Printme( ); 错，不能继承父类的private方法	
     }
}
