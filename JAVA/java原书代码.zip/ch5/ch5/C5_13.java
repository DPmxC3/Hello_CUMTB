﻿package ch5;
class  A5
{
  int  x=4;  int  y=1;
  public  void  printme( )
  {
     System.out.println("x="+x+" y="+y);
     System.out.println("class name: "+this.getClass( ).getName( ));
  }
}
public class  C5_13  extends  A5
{
  int  x;
    @Override
  public  void  printme( )
  { int  z=super.x+6;  	//引用父类(即A5类)的数据成员
    super.printme( ); 	//调用父类(即A5类)的成员方法
    System.out.println("I am an  "+this.getClass( ).getName( ));
    x=5;
    System.out.println(" z="+z+"  x="+x);   //打印子类的数据成员
  }
  public  static  void  main(String  arg[ ])
  {  int  k;
    A5  p1=new  A5( );
    C5_13  p2=new  C5_13( );
    p1.printme( );
    p2.printme( );
  //  super.printme( );  //错，在static方法中不能引用非static成员方法
  //  k=super.x+23;    	//错，在static方法中不能引用非static数据成员
  }
}   

