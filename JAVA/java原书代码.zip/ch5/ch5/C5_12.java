﻿package ch5;
public  class  C5_12  
 {
    public static void main(String[ ] args)
    {  double x;
       Circle  cir=new  Circle(5.0);
       x=cir.area( );
       System.out.println("圆的面积="+x);
       x=cir.perimeter( );
       System.out.println("圆的周长="+x);
    }
 }
 class  Circle
 {
   double r;   				//定义半径
   final double PI=3.14159265359;   	//定义圆周率
   public  Circle(double r)  		//类的构造方法
   {   this.r=r;    }
   double area( )  			//计算圆面积的方法
   {    return PI*r*r; }  		//通过构造方法给r赋值
   double perimeter( )  		//计算圆周长的方法
   {
      return 2*(this.area( )/r);      	//使用this变量获取圆的面积
   }
}

