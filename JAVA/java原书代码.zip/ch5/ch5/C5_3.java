package ch5;
class  P1
{  private  int  n=9;  //私有数据成员n
   int  nn;
    P1( )  //构造方法
    {  nn=n++; }  //可以被该类的对象自身访问和修改
    
   void  ma( )
     {  System.out.println("n="+n); } //可以被该类的对象自身访问 

}
public  class  C5_3  extends  P1  //类class  C5_3是类P1的子类
{
   public static void main(String[ ] args)
   {
       P1  m1=new  P1( );
       System.out.println("m1.nn="+m1.nn);
       // System.out.println("m1.n="+m1.n); 错，不能引用父类的私有成员
       m1.ma( );  //可以引用类P1自身的成员方法
    }
}
