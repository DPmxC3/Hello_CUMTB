package ch5;
public  class  C5_2
{
   public  static  void  main(String[ ]  args)
    {
      double  a=2.2,b=3.1,z;
/*在类C5_2中创建被访问ClassArea类的ss的对象，并访问对象
 * 的成员方法。这就是说，包中类是可见的，可以互相引用*/
      ClassArea  ss=new  ClassArea( );
      z=ss.area(a,b);    //ss引用对象的成员方法
      System.out.println("z="+z);
    }
}
