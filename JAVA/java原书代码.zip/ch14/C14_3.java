package ch14;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
public  class  C14_3
{ public  static  void  main(String  args[ ])
   {   byte a1=25,a2=67;
       byte b[]={'I',' ','L','O','V','E',' ','J','A','V','A','!'};
       try{
        PipedInputStream pin=new PipedInputStream( );
        PipedOutputStream pout=new PipedOutputStream(pin);  //建立pin与pou的连接
        //创建ByteArrayInputStream类bin的对象，并与b数组绑定
ByteArrayInputStream bin = new ByteArrayInputStream(b);  
        ByteArrayOutputStream bout = new ByteArrayOutputStream( ); 
        System.out.println("PipedInputStream 和 PipedOutputStream");
        System.out.println("\t将数据 "+a1+" 送到 pout ");
        pout.write(a1);  
        System.out.println("\t将数据 "+a2+" 送到 pout ");
        pout.write(a2);
        System.out.println("\t由pin读入数据a1 "+(byte)pin.read( ));
        System.out.println("\t由pin读入数据a2 "+(byte)pin.read( ));
        int n=b.length;  //获取b数组的长度
        bin.skip(n/2);  //使读操作指针位于字节流的中间位置，即从数组b下标的中间位置读起
        int m; 
//将bin的对象数据写入ByteArrayOutputStream中
        while(bin.available( )>0)  //bin.available( )返回输入流中的可读字节数
         { //从bin中读一个字节的数据送到bout中，然后读指针与写指针后移一个字节位置
bout.write(bin.read( ));
}
        System.out.print("读写一半的数据 ");
        bout.writeTo(System.out);  //输出到屏幕上
        bin.reset( );         //设读操作指针到流的开头
        bout.reset( );        //设写操作指针到流的开头
        m=b.length; 
        byte  rb[ ]=new  byte[m];  
        bin.read(rb,0,10);    //从数据流取10个字节放入数组rb[ ]
        bout.write(rb,0,10);  //将数组rb[ ]从0开始的10个字节写到输出流
        System.out.println("\n输出读/写所有数据"+bout.toString( ));
       }
      catch(Exception e)
      {  System.out.println("发生I/O错误!");  }
   }
}
