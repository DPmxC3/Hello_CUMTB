package ch14;
import java.io.*;
public class C14_7
{
 public static void main(String [ ] args)
  {
    char c;
    int c1;
    File filePath=new File("temp");  //在当前目录下建目录，也可用绝对目录
    if(!filePath.exists( ))filePath.mkdir( );  //若目录不存在，则建之
    File fl=new File(filePath,"d1.txt");  //在指定目录下建文件类对象
    try {
       FileOutputStream fout=new FileOutputStream(fl); 
       System.out.println("请输入字符,输入结束按# :");
       while((c=(char)System.in.read( ))!='#')  //将从键盘输入的字符写入磁盘文件
          {  fout.write(c);  }
       fout.close( );  //
       System.out.println("\n打印从磁盘读入的数据");
       FileInputStream fin=new FileInputStream(fl);
       while((c1=fin.read( ))!=-1)   //磁盘文件读入程序
            System.out.print((char)c1);  //打印从磁盘读入的数据到屏幕上
       fin.close( );
      } //try结束
     catch(FileNotFoundException e) {
       System.err.println(e);}
     catch(IOException e){
      System.err.println(e);}
    } //main( )结束
}  //class C14_7结束
