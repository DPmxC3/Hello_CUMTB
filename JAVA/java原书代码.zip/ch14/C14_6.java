package ch14;
import java.io.File;
import java.util.Date;
public  class  C14_6
{
   public static void main(String args[ ])
   { 
      File ListFile[ ];
      long totalSize=0;
      int  FileCount=0,DirectoryCount=0;  
      File f=new File("E:/Java");   //生成File对象
      System.out.println("目录: "+f.getParent( )+"\n");
      if(f.exists( ) != true)      //若文件不存在则结束程序
      {  System.out.println(f.getPath( )+"不存在!");
         return;
      } 
      if(f.isDirectory( ))       //若路径为目录时
       { ListFile=f.listFiles( );  //取得文件列表
         for(int i=0;i<ListFile.length;i++)
         {  System.out.print((ListFile[i].isDirectory( )?"D":"X") + "  ");
            System.out.print(new Date(ListFile[i].lastModified( )) + "  ");
            System.out.print(ListFile[i].length( ) + "  ");
            System.out.print(ListFile[i].getName( ) + "\n");
            if(ListFile[i].isFile( ))FileCount++;      //计算文件数
            else   DirectoryCount++;  //计算目录数
            totalSize =totalSize+ListFile[i].length( );  //计算文件大小总和
         }
         System.out.println("\n\t\t目录数: "+DirectoryCount);
         System.out.println("\t\t文件数: "+FileCount);
         System.out.println("\t\t总字节: "+totalSize); 
      }
      else     //路径为文件时
      {    
         System.out.print((f.isDirectory( )?"D":"X")+"  ");
         System.out.print(new Date(f.lastModified( ))+"  ");
         System.out.print(f.length( )+"  ");
         System.out.print(f.getName( )+"\n");
         FileCount++;
         totalSize=totalSize+f.length( );
         System.out.println("\n\t\t目录数: "+DirectoryCount);
         System.out.println("\t\t文件数: "+FileCount);
         System.out.println("\t\t总字节: "+totalSize); 
      }
   }   
} 

