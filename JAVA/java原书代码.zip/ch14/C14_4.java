package ch14;
import  java.io.*;
public  class  C14_4
{
   public  static  void  main(String args[ ])
   {  char   c1[ ],c2[ ];
      String str;
      CharArrayReader cin; 
      CharArrayWriter cout;
      //将键盘上输入的数据放入到BufferedReader类in的对象中
      InputStreamReader sin=new InputStreamReader(System.in); 
      BufferedReader in=new BufferedReader(sin);
      OutputStreamWriter out=new OutputStreamWriter(System.out);  //屏幕输出 
      try
      {  System.out.print("请输入一个字符串,请按Enter结束  ");
         str=in.readLine( );   //读入字符串     
         c1=str.toCharArray( );  //将字符串转换成字符数组
         //创建CharArrayReader类cin的对象，并与输入流c1数组绑定
         cin=new CharArrayReader(c1); 
         cout=new CharArrayWriter( );
         //读cin的对象数据内容到cout的对象中
         while(cin.ready( ))    //(cin.ready( )返回输入流是否可读信息  
          {  //读cin中的一个字符并写到cout中，读/写指针后移一个字符位置
         cout.write(cin.read( ));    
       }
         System.out.print("c2=");
         c2=cout.toCharArray( );  //将cout的对象数据写到字符数组c2中
         System.out.print(new String(c2));  //用c2字符数组创建字符串对象并打印
         System.out.print("\n将cout的对象数据写入out的对象中，并输出: ");
         cout.writeTo(out);       //将cout的对象数据写入out的对象中
         out.flush( );            //强制输出out中的数据到屏幕
      }
      catch(IOException E)
      {   System.out.println("I/O错误!");  }
   }     
}

