package ch14;
import  java.io.*;
public  class C14_8
{
   public  static  void  main(String  args[ ])
   {
      boolean  lo=true;  
      short  si=-32768;
      int i=65534;     
      long l=134567;
      float f=(float)1.4567;   
      double d=3.14159265359;
      String str1="ABCD";      
      String str2="Java语言教学"; 
      try
      {  FileOutputStream fout=new FileOutputStream("t1.txt");
         DataOutputStream out=new DataOutputStream(fout);  //文件输出流对象为参数
         FileInputStream fin=new FileInputStream("t1.txt");
         DataInputStream in=new DataInputStream(fin);  //文件输入流对象为参数
         //将数据写入t1.txt文件
         out.writeBoolean(lo); out.writeShort(si);
         out.writeByte(i);     out.writeInt(i);
         out.writeLong(l);     out.writeFloat(f);
         out.writeDouble(d);   out.writeBytes(str1);
         out.writeUTF(str2);
         out.close( ); 
         //将t1.txt文件的数据读出，并屏幕输出
         System.out.println("Blooean lo="+in.readBoolean( ));
         System.out.println("Short si="+in.readShort( ));
         System.out.println("Byte i="+in.readByte( ));
         System.out.println("Int i="+in.readInt( ));
         System.out.println("Long l="+in.readLong( ));
         System.out.println("Float f="+in.readFloat( ));
         System.out.println("Double d="+in.readDouble( ));
         byte b[ ]=new byte[4];
         in.readFully(b);
         System.out.print("str1=");
         for(int j=0;j<4;j++)System.out.print((char)b[j]);
         System.out.println( );         
         System.out.println("str2="+in.readUTF( ));
         in.close( );        
      }
      catch(IOException E)
      {
         System.out.println(E.toString( ));
      }
   }
}

