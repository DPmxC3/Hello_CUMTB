package ch7;
public class C7_4
{    
    public static void main(String args[ ]) 
       {  String s1="Java";
          String s2="java";
          String s3="Welcome";
          String s4="Welcome";
          String s5="Welcoge";
          String sc1=s3.concat(s1);      // sc1指向对象为"Welcome Java "
          String sc2=s1.concat("abx");
          String sr1=s3.replace('e','r');    //s3指向对象中的字符'e'换成'r'
          String w1=s5.toLowerCase( );   //s5指向对象中的大写换小写
          String u2=s2.toUpperCase( );   //s2指向对象中的小写换大写
          System.out.println("s1="+s1+"\ts2="+s2);
          System.out.println("s3="+s3+"\ts4="+s4);
          System.out.println("s5="+s5);
          System.out.println("s3+s1="+sc1);
          System.out.println("s1+abx="+sc2);
          System.out.println("s3.replace('e','r')="+sr1);
          System.out.println("s5.toLower="+w1);
          System.out.println("s2.toUpper="+u2);
     }
}

