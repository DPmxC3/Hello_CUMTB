package ch7;
class  A1
{  int  x,y;
   A1(int x,int y){this.x=x;this.y=y;}
   @Override
   public  String  toString( ){ return ("\tx="+x+"\t,y="+y); }
}
public  class  C7_6
{ 
    public  static  void  main(String  args[ ]) 
     {  A1 p=new A1(2,6);   //调用构造方法初始化
        // String.valueOf(p) 返回p指向的对象的字符串表示。
        String str=String.valueOf(p); 
        System.out.println("str="+str);
     }

 }

