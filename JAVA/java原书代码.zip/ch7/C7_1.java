package ch7;

import java.io.UnsupportedEncodingException;

public  class  C7_1
{
  public  static  void  main(String[ ]  args) throws UnsupportedEncodingException
  {//字符数组型的字符串
    char  charArray[ ]={'b','i','r','t','h',' ','d','a','y'};
    //字节数组型的字符串，其中每个字节的值代表汉字的国际机内码
   //汉字的国际机内码（GB2312码），两个字节的编码构成一个汉字。
   //数组构成“面向对象”4个汉字。-61与-26组合成汉字“面”，其余类推
    byte  byteArray[ ]={-61,-26,-49,-14,-74,-44,-49,-13};
    StringBuffer  buffer;  //声明字符串对象的引用变量
    String  s,s1,s2,s3,s4,s5,s6,s7,ss;  //声明字符串对象的引用变量
    s=new String("hello");  //创建一个字符串对象"hello"，s指向该对象
    ss="ABC";  //创建一个字符串对象" ABC "，ss指向该对象
    //用StringBuffer创建一个字符串对象
    buffer=new StringBuffer("Welcom to java programming! ");
    s1=new String( );  //创建一个空字符串对象
    s2=new String(s);  //创建一个新的 String 对象"hello"，s2指向该对象
    s3=new String(charArray); //用字符数组创建字符串对象"birth day"，s3指向该对象
    //用字符串数组中下标为6开始的3个字符创建字符串对象"day"
    s4=new String(charArray,6,3);
   //用字符串数组byteArray按缺省的字符编码方案创建串对象"面向对象"
    s5=new String(byteArray,"GB2312"); 
      //从前面创建的字节型数组byteArray下标为2的字节开始，取连续的4个字节，
//即取{-49, -14, -74, -44}，创建字符串对象
    s6=new String(byteArray,2,4,"GB2312"); 
    //创建一个新的 String 对象" Welcom to java programming!"，s7指向该对象
    s7=new String(buffer); 
    System.out.println("s1="+s1);
    System.out.println("s2="+s2);
    System.out.println("s3="+s3);
    System.out.println("s4="+s4);
    System.out.println("s5="+s5);
    System.out.println("s6="+s6);
    System.out.println("s7="+s7);
    System.out.println("ss="+ss);
    System.out.println("buffer="+buffer);
  }
 }

