package ch7;
public  class  C7_7
{
   public  static  void  main(String[ ]  args)
  {
    for(int  i=0;i<args.length;i++)
     System.out.println(args[i]);
   }
}

