package ch7;
public  class  C7_10
{
  public  static  void  main(String[ ]  args)
  {
    Object  y="hello";
    String  s="good bye";
    char  cc[ ]={'a','b','c','d','e','f'};
    boolean  b=false;
    char  c='Z';
    long  k=12345678;
    int  i=7;
    float  f=2.5f;
    double  d=33.777;
    StringBuffer  buf=new StringBuffer( );
    buf.insert(0,y); buf.insert(0,' '); buf.insert(0,s);
    buf.insert(0, ' '); buf.insert(0,cc); buf.insert(0,' ');
    buf.insert(0,b); buf.insert(0,' '); buf.insert(0,c);
    buf.insert(0, ' '); buf.insert(0,i); buf.insert(0,' ');
    buf.insert(0,k); buf.insert(0,' '); buf.insert(0,f);
    buf.insert(0,' '); buf.insert(0,d); 
    System.out.println("buf="+buf);
  }
 }

