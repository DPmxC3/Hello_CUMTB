package ch7;
public class C7_3 {
 public  static  void  main(String  args[ ]) 
    {  String  s1="Java";
       String  s2="java";
       String  s3="Welcome";
       String  s4="Welcome";
       String  s5="Welcoge";
       String  s6="student";
       boolean  b1=s1.equals(s2);   //s1指向的对象为当前串，s2指向的对象为模式串
       boolean  b2=s1.equals("abx");
       boolean  b3=s3.equals(s4);
       boolean  b4=s1.equalsIgnoreCase(s2);
       int  n1=s3.compareTo(s4);
       int  n2=s1.compareTo(s2);
       int  n3=s4.compareTo(s5);
       int  d1=s6.compareTo("st");
       int  d2=s6.compareTo("student");
       int  d3=s6.compareTo("studentSt1");
       int  d4=s6.compareTo("stutent");
       System.out.println("s1="+s1+"\ts2="+s2);
       System.out.println("s3="+s3+"\ts4="+s4);
       System.out.println("s5="+s5);
       System.out.println("equals: (s1==s2)="+b1+"\t(s1==abx)="+b2);
       System.out.println("equals: (s3==s4)="+b3);
       System.out.println("equalsIgnoreCase: (s1==s2)="+b4);
       System.out.println("(s3==s4)="+n1+"\t(s1<s2)="+n2);
       System.out.println("(s4>s5)="+n3);
       System.out.println("d1="+d1+"\td2="+d2);
       System.out.println("d3="+d3+"\td4="+d4);
    } 
}
