package ch7;
public  class  C7_11
{
  public  static  void  main(String[ ]  args)
  { StringBuffer  buf=new StringBuffer("hello there");
    System.out.println("buf="+buf.toString( ));
    System.out.println("char at 0: "+buf.charAt(0));
    buf.setCharAt(0,'H');   //将buf指向的串对象的下标为0的字符改写为'H'
    buf.setCharAt(6,'T');   //将buf指向的串对象的下标为6的字符改写为'T'
    System.out.println("buf="+buf.toString( ));
  }
}

