package ch7;
public  class  C7_5
{ 
    public  static  void  main(String  args[ ]) 
    {  double  m1=3.456;
       String  s1=String.valueOf(m1);   	//将double型值转换成字符串
       char[ ]  cc={'a','b','c'};
       String  s2=String.valueOf(cc);   	//将字符数组转换成字符串
       boolean  f=true;
       String  s3=String.valueOf(f);   	//将布尔值转换成字符串
       char[ ]  cs={'J','a','v','a'};
       String  s4=String.valueOf(cs,2,2);
       System.out.println("m1="+m1+"\ts1="+s1);
       System.out.println("s2="+s2);
       System.out.println("f="+f+"\ts3="+s3);
       System.out.println("s4="+s4);
    }
}
