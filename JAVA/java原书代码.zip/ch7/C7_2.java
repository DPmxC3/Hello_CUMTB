package ch7;
public class C7_2
{ 
    public static void main(String args[ ]) 
    {  String s1="Java Application";
       char cc[ ]={'J','a','v','a',' ','A','p','p','l','e','t'};
       int len=cc.length;            	//返回cc字符数组对象的长度
       int len1=s1.length( );         	//返回s1字符串对象的长度
       int len2="ABCD".length( );    	//返回字符串"ABCD"的长度
       char c1="12ABG".charAt(3);    	//返回字符串"12ABG"的下标为3的字符
       char c2=s1.charAt(3);         	//返回s1字符串对象的下标为3的字符
       // char c3=cc.charAt(1);错，不能这样用
       //返回当前串内第一个与指定字符ch相同的字符的下标
       int n1="abj".indexOf(97);    
       int n2=s1.indexOf('J');
       int n3="abj".indexOf("bj",0);
       int n4=s1.indexOf("va",1);
       //返回当前串中的子串
       String s2="abcdefg".substring(4);
       String s3=s1.substring(4,9);
       System.out.println("s1="+s1+" len="+len1);
       System.out.println("cc="+cc+" len="+len);   //不能这样打印cc数组元素的内容
       System.out.println("ABCD=ABCD"+"  len="+len2);
       System.out.println("c1="+c1+"  c2="+c2);
       System.out.println("n1="+n1+"  n2="+n2);
       System.out.println("n3="+n3+"  n4="+n4);
       System.out.println("s2="+s2);
       System.out.println("s3="+s3);
    }
}
