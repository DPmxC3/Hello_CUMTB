package ch11;
public class C11_7 {
    public static void main(String[] args) {
       
    }
}
