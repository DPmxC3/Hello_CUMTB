package ch11;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
public class  C11_6 extends JFrame 
  {
      JTextArea tf=new JTextArea( );
      JMenuBar bar=new JMenuBar( );  //创建JMenuBar对象
      JMenu menu=new JMenu("文件");  //创建JMenu对象
      JMenuItem newf=new JMenuItem("新建");  //创建JMenuItem对象
      JMenuItem open=new JMenuItem("打开");
      JMenuItem close=new JMenuItem("关闭");    
      JMenuItem quit=new JMenuItem("退出");
      public  C11_6( ) 
      {   super("C11_6");       //设定JFrame的标签
          getContentPane( ).add(new JScrollPane(tf));  //创建JFrame的容器对象 
          tf.setEditable(false);  //设置文本区域不可编辑
          bar.setOpaque(true);   //设置bar为不透明，若设置bar为透明，则在选择菜单时
                             //会有残影存留在JMenuBar上
          setJMenuBar(bar);      //加入bar到Jframe中
          menu.add(newf);       //加入JMenuItem对象到menu中
          menu.add(open);    menu.add(close);        
          menu.addSeparator( );  //在JMenu中加入一分隔线
          menu.add(quit);    bar.add(menu);      //将menu加载到bar上 
          newf.addActionListener(new Ac( )); //注册JMenuItem对象给监听者对象
          open.addActionListener(new Ac( ));
          close.addActionListener(new Ac( ));
          quit.addActionListener(new Ac( ));
          addWindowListener(new WinLis( ));
       }
     class Ac implements ActionListener
     {
       
       @Override
       public void actionPerformed(ActionEvent e)
        {   if(e.getSource( )==newf)tf.setText("新建");
            if(e.getSource( )==open)tf.setText("打开");
            if(e.getSource( )==close)tf.setText("关闭");
            if(e.getSource( )==quit)System.exit(0);
        }
     }      
    class WinLis extends  WindowAdapter
     { 
        @Override
       public void windowClosing(WindowEvent e){ System.exit(0); }
     }
    public static void main(String[ ] args)
     {  JFrame f = new  C11_6 ( );
        f.setSize(400,200);   f.setVisible(true); 
     } 
}

