package ch11;
import java.awt.Container;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class  C11_3 
  {  JLabel  lb1=new JLabel("这是第一个窗口"); 
     JLabel  lb2=new JLabel("这是第二个窗口");
     public static void main(String[ ] arg) 
      {  C11_3 c= new  C11_3( );  }
     public  C11_3( )
      { JFrame f1=new JFrame( ); //创建JFrame对象
        JFrame f2=new JFrame( );        
        Container cp=f1.getContentPane( ); //创建JFrame的容器对象，获得ContentPane
        Container cp1=f2.getContentPane( );  
        f1.setTitle("JFrame1");
        f2.setTitle("JFrame2");
        f1.setSize(150,100); //设置窗口大小 
        f2.setSize(150,100);        
        cp.add(lb1);    
        f1. setVisible(true);     //设置窗口为可见
        cp1.add(lb2);    
        f2. setVisible(true);
        f1.addWindowListener(new WinLis()); 
        f2.addWindowListener(new WinLis()); 
      }
     class  WinLis  extends  WindowAdapter
     {  @Override
 public void windowOpened(WindowEvent e)
        {  }  //打开窗口
        @Override
       public void windowActivated(WindowEvent e)
        {  }  //将窗口设置成活动窗口
        @Override
       public void windowDeactivated(WindowEvent e) 
        { }  //将窗口设置成非活动窗口
        @Override
       public void windowClosing(WindowEvent e) 
        {    System.exit(0);  }    //窗口关闭
        @Override
       public void windowIconified(WindowEvent e) 
        { }  //最小化窗口
     }   
}

