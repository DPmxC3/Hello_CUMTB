package ch11;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import javax.swing.*;
public class C11_5 extends JFrame
 { // 创建 JTabbedPane 对象，并指定标签显示在上方
   JTabbedPane jtab=new JTabbedPane(JTabbedPane.TOP); 
   JScrollPane sp; //声明JScrollPane对象
   public static void main(String args[ ])
    { C11_5 f=new C11_5( );  
      f.setTitle("JTabbedPane对象的应用");    
      f.setSize(300,300); 
      f.setVisible(true);
    }
   public  C11_5( )  
   { 
      JLabel lb[ ]=new JLabel[6];  //声明JLabel 数组
      Icon pic;  //创建图片对象
      String title;  //创建标签名称对象
      String p;
      for(int i=1;i<=5;i++)
      {  p="/image/"+"00"+i+".jpg";
         pic=new ImageIcon(getClass().getResource(p)); //获得图片
         lb[i]=new JLabel( );  //创建 JLabel 对象
         lb[i].setIcon(pic);  //设定 JLabel 图标
         title = "第 "+ String.valueOf(i) +" 页";  //设定标签名称
         jtab.add(title,lb[i]);  //将 JLabel 对象加入 jtab
      }
      getContentPane( ).add(jtab);  //将 jtab加入到窗口中
      int v=ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED;
      int h=ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED;
      sp=new JScrollPane(jtab,v,h);  //创建JScrollPane对象,并加载jtab对象
      getContentPane( ).add(sp);  //将 sp 加入窗口中
      addWindowListener(new WinLis( ));
    }
   class WinLis extends WindowAdapter
    {   @Override
      public void windowClosing(WindowEvent e){ System.exit(0); }
    }
 }

