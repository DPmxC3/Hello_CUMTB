package ch12;
public class C12_1 {
    public static void main(String[] args) {
     int  a,b,c;
     a=67; b=0; 
     c=a/b;
     System.out.println(a+"/"+b+"="+c);   
    }
}
