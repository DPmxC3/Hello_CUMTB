package ch12;
public  class  C12_3
{
   static  int  a,b,c; 
   public  static  void  main(String  args[ ])
   {
      try
      {  a=10;
         b=0;
         try
         {  c=a/b;
            System.out.println("a/b = " + c);
         }
         catch(IndexOutOfBoundsException E)
         {   System.out.println("捕捉超出索引异常...");   }
         finally
         {
            System.out.println("嵌套内层的finally区块");
         }
      }  
      catch(ArithmeticException E)
      {   System.out.println("捕捉数学运算异常：b="+b);   }
      finally
      {  System.out.println("嵌套外层的finally区块");
         if(b == 0)
            System.out.println("程序执行发生异常!");
         else
            System.out.println("程序正常执行完毕!");
      }
   }
}

