package ch12;
public class C12_2 {
   public  static  void  main(String  args[ ])
   {   int a,b,c;
       a=67;  b=0;  
   try
    {  int x[ ]=new int[-5];
       c=a/b;
       System.out.println(a+"/"+b+"="+c);
     }
    catch(NegativeArraySizeException e)
    {   System.out.println("exception: " + e.getMessage( ));
        e.printStackTrace( );
    }
    catch(ArithmeticException e) 
    {     System.out.println("b=0: " + e.getMessage( ));    }
     finally
     {     System.out.println("end");    }
   }

}
