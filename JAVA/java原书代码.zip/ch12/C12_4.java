package ch12;
public  class  C12_4  
  {
    public static void main(String [ ] args)
     {
       try
        { throw new NullPointerException("自编异常"); }
       catch(NullPointerException e) 
        {  System.out.println("exception:"+e);    }
    }
 }


