package ch12;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JApplet;
public  class  C12_5  extends  JApplet 
{ 
   static void throwOne( ) throws  IllegalAccessException
    {  throw new IllegalAccessException("自编异常"); }
    @Override
   public  void  paint(Graphics  g)
    {
      Graphics2D  g2=(Graphics2D)g;  
      try{  throwOne( );  }
      catch(IllegalAccessException  e)
       {   g2.drawString("发生异常："+e,20,20);    }
   }
}

