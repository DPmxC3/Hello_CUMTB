package ch6;
public class C6_11
{   public static void main(String arg[ ])
    {  int i,j;
       int len1[ ]=new int[2];
       int len2[ ]=new int[2];
       int[ ][ ] a1={{1,4,8,9},{3,2,2}};
       int a2[ ][ ]={{90,3},{9,12}};
       System.out.println("a1.length="+a1.length); 
       for(i=0;i<2;i++)
        {  len1[i]=a1[i].length; //将a1数组的元素i的长度赋给len1[i]
           System.out.println("a1[ ].length="+len1[i]);
        }      
       for(i=0;i<2;i++)
        { for(j=0;j<len1[i];j++) 
           System.out.print("  "+a1[i][j]);
          System.out.println("\n");
        }
       System.out.println("a2.length="+a2.length);
       for(i=0;i<2;i++)
        {  len2[i]=a2[i].length;   //将a2数组的元素i的长度赋给len2[i]
           System.out.println("a2[ ].length="+len2[i]);
        }
        //打印a2数组对象的值
        for(i=0;i<2;i++)
        { for(j=0;j<len2[i];j++) 
           System.out.print("  "+a2[i][j]);
          System.out.println("\n");
        }
       a2=a1;//将a1数组赋给a2，说明a2指向a1指向的数组对象
       System.out.println("a1.length="+a1.length);
       for(i=0;i<2;i++)
        {  len1[i]=a1[i].length;  //将a1数组的元素i的长度赋给len1[i]
           System.out.println("a1[ ].length="+len1[i]);
        }
       //打印a1数组的对象的值
        for(i=0;i<2;i++)
        { for(j=0;j<len1[i];j++) 
           System.out.print("  "+a1[i][j]);
          System.out.println("\n");
        }
       System.out.println("a2.length="+a2.length);
       for(i=0;i<2;i++)
        {  len2[i]=a2[i].length;  //将a2数组的元素i的长度赋给len2[i]
           System.out.println("a2[ ].length="+len2[i]);
        }
       //打印a2数组的对象的值
        for(i=0;i<2;i++)
        { for(j=0;j<len2[i];j++) 
           System.out.print("  "+a2[i][j]);
          System.out.println("\n");
        }
       System.out.println("\n");
    }
}
