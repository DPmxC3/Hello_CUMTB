package ch6;
class SelectSort
{  
   static void sort(int arr1[ ])  //成员方法的形参是数组
   {  
      int i,j,k,t;
      int len=arr1.length;
      for(i=0;i<len-1;i++) //外循环开始
       {
         k=i;
           for(j=i+1;j<len;j++)
              if( arr1[j]<arr1[k]) k=j;   //内循环只用k记录最小值的下标
         if(k>i)
           {  t=arr1[i];        //在外循环实施交换，可减少交换次数
              arr1[i]=arr1[k];
              arr1[k]=t;
           }   // if(k>i)结束
      } //外循环for(i…)结束
   }   //成员方法sort定义毕
}
public class C6_9 extends SelectSort
{  
   public static void main(String[ ] args)
   {  
      int arr[ ]={78,70,2,5,-98,7,10,-1};
      int len=arr.length;
      SelectSort.sort(arr);   //数组名作为成员方法的实参
      System.out.print("选择法排序的结果：");
      System.out.println("length="+arr.length);
      for(int i=0;i<len;i++)
         System.out.print(" "+arr[i]);   //数组arr的值已在方法调用中被改变了
      System.out.println("\n");   
    }
 }
