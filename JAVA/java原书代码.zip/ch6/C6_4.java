package ch6;
public class C6_4 {
   public static void main(String arg[ ])
    {  int i;
       int[ ] a1={2,5,8,25,36};
       int a3[ ]={90,3,9};
       System.out.println("a1.length="+a1.length);
       System.out.println("a3.length="+a3.length);
       a3=a1;   //赋值的结果是a3指向a1指向的数组，
//而a3先前指向的含有3个元素的数组由于没有指向而消失
       System.out.print("a1:");
       for(i=0;i<a1.length;i++)
         System.out.print("  "+a1[i]);
       System.out.println("\n");
       System.out.println("a3.length="+a3.length);
       System.out.print("a3:");
       for(i=0;i<a3.length;i++)
         System.out.print("  "+a3[i]);
       System.out.println("\n");
    }

}
