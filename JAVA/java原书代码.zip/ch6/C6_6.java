package ch6;
class Add1Class
{ void add(int arA[ ],int arB[ ])
   { int i;
     int len=arA.length;
     for(i=0;i<len;i++)
       arB[i]=arA[i]+arB[i];
   }
}
public class C6_6  
{  public static void main(String[ ] args)
   { int i;
     int arX[ ]={1,3,7,6};
     int arY[ ]={78,0,42,5};
     int len=arX.length;
     Add1Class p1=new Add1Class( );
     System.out.println(" arX的原始数据"); //打印X数组
     for(i=0;i<len;i++)
       System.out.print(" "+arX[i]);
     System.out.println("\n arY的原始数据"); //打印Y数组
     for(i=0;i<len;i++)
       System.out.print(" "+arY[i]);
     p1.add(arX,arY);       //p1引用对象的add方法计算两个数组之和
     System.out.println("\n  再次输出arX"); //再次打印X数组
     for(i=0;i<len;i++)
       System.out.print(" "+arX[i]);
     System.out.println("\n 再次输出arY"); //再次打印Y数组
     for(i=0;i<len;i++)
       System.out.print(" "+arY[i]);
     System.out.println("\n");
    }
  }

