package ch6;
class Student
{  private String name;
   private char sex; 
   private double score;
   Student(String cname,char csex,double cscore)
   {  name=cname;
      sex=csex;
      score=cscore;
   }
   String getName( ){return name;}
   char getSex( ){return sex;}
   void studPrint( )
   { System.out.println("Name: "+name+"\tSex: "+sex+"\tScore: "+score);}
}

public class C6_10
{   public static void main(String[ ] args)
    {String mname;
     char msex;
     int len;   
     Student[ ]  st1=new Student[3];   //声明对象数组，用new为每一个对象分配存储空间
     st1[0]=new Student("li",'F',89); 
     st1[1]=new Student("he",'M',90); 
     st1[2]=new Student("zhang",'M',78); 
     len=3;
     //对象数组元素的引用
     for(int i=0;i<len;i++)  st1[i].studPrint( );
     mname=st1[1].getName( );  msex=st1[1].getSex( );
     System.out.println("Name 1:"+mname+"\tSex:"+msex);
    }
}

