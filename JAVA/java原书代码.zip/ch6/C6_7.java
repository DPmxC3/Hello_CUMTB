package ch6;
public class C6_7 
{  static double average(double ascore[ ])
   { double aaver=0;
     for(int i=0;i<ascore.length;i++)   aaver=aaver+ascore[i];
     aaver=aaver/ascore.length;
     return aaver;
   }
   public static void main(String arg[ ])
   {   double aver1,aver2;
       double s1[ ]={90,56,86.5,87,99,67.5,65,80};
       double s2[ ]={70,90,87,99,67};
       System.out.println("s1.length="+s1.length);
       aver1=average(s1);//数组名s1作为average成员方法的实参
       System.out.println("aver1="+aver1);
       System.out.println("s2.length="+s2.length);
       aver2=average(s2); //数组名s2作为average成员方法的实参
       System.out.println("aver2="+aver2);
    }
}   
