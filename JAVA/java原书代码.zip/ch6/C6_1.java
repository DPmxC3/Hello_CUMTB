package ch6;
public class C6_1 
{
   public static void main(String arg[ ])
    {
       int i;
       double a1[ ];  //[ ]放在引用变量后面声明
       char[ ] a2;   //[ ]放在引用变量前面声明
       a1=new double[8];  //创建a1数组，数组元素个数为8，类型double型
       a2=new char[8];  //创建a2数组，数组元素个数为8，类型char型
       int a3[ ]=new int[8];  //创建a3数组，数组元素个数为8，类型int型
       byte[ ] a4=new byte[8];  //创建a4数组，数组元素个数为8，类型byte型
       char a5[ ]={'A','B','C','D','E','F','H','I'};  //创建a5数组，直接指定初值
          //下面各句测定各数组的长度
       System.out.println("a1.length="+a1.length);
       System.out.println("a2.length="+a2.length);
       System.out.println("a3.length="+a3.length);
       System.out.println("a4.length="+a4.length);
       System.out.println("a5.length="+a5.length);
       //以下各句引用数组中的每一个元素，为各元素赋值
       for(i=0;i<8;i++)
       { a1[i]=100.0+i;
         a3[i]=i;
         a2[i]=(char)(i+97);//将整型转换为字符型
       }  
       //下面各句打印各数组元素
       System.out.println("\ta1\ta2\ta3\ta4\ta5");
       System.out.println("\tdouble\tchar\tint\tbyte\tchar");
       for(i=0;i<8;i++)
       System.out.println("\t"+a1[i]+"\t"+a2[i]+"\t"+ a3[i]+"\t"+a4[i]+"\t"+a5[i]);
    }
}   

