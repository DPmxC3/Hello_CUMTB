package ch6;
class Ff
{  int aa(int x,int y)   //定义方法aa，有两个整型形参x和y
   { int z;
     x=x+4;y=y+2;    z=x*y;     return z;
   }
}
public class C6_5   
{
  public static void main(String[ ] args)
   { int arr[ ]={6,8,9};   //声明并初始化数组arr
     int len=arr.length, k;
     Ff p1=new Ff( );
     k=p1.aa(arr[0],arr[1]);   //数组元素arr[0]和arr[1]作为方法aa的实参
     System.out.println("k="+k);
     for(int i=0;i<len;i++)
        System.out.print("  "+arr[i]);   //循环输出数组元素的值
     System.out.println("\n"); 
  }
}
