package ch6;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class FindSearch
{  int binarySearch(int arr[ ],int searchValue)
   {  int low=0;// low是第一个数组元素的下标
      int high=arr.length-1; 		// high是最后一个数组元素的下标
      int mid=(low+high)/2;  		// mid是中间那个数组元素的下标
      while(low<=high && arr[mid]!=searchValue)
      {  if( arr[mid]<searchValue) 
            low=mid+1;			//要找的数可能在数组的后半部分中
         else
            high=mid-1; 		//要找的数可能在数组的前半部分中
         mid=(low+high)/2;
      }
      if(low>high) mid=-1;
      return mid;   // mid是数组元素下标，若为-1，则表示不存在要查的元素
   }
}  

public class C6_3
{
  public static void main(String[ ] args)throws IOException
  {  BufferedReader keyin=new BufferedReader(new InputStreamReader(System.in));
     int i,search,mid;
     String c1;
     int arr[ ]={2,4,7,18,25,34,56,68,89};
     System.out.println("打印原始数据");
     for(i=0;i<arr.length;i++)  System.out.print(" "+arr[i]);
     System.out.println("\n");
     System.out.println("请输入要查找的整数");
     c1=keyin.readLine( );
     search=Integer.parseInt(c1);   //取出字符串转换为整型数赋给search
     FindSearch p1=new  FindSearch( );
     mid=p1.binarySearch(arr,search);
     if(mid==-1)  System.out.println("没找到！");
     else  System.out.println("所查整数在数组中的位置下标是："+mid);
  }
}
