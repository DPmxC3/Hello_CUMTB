package ch6;
class Maxvalue
{ int maxvl(int arr1[ ][ ])
   {
     int i,k,max;
     int len=arr1.length,len1;
     max=arr1[0][0];
     for(i=0;i<=len-1;i++)
      { len1=arr1[i].length;
        for(k=0;k<len1;k++)
          if( arr1[i][k]>max) max=arr1[i][k];
      }
     return  max;
   }
}
public class C6_12
 {
  public static void main(String[ ] args)
   { int maxx;
     int arr[ ][ ]={{1,3,7,6},{78,0,42,5},{-98,7,10,-1}};
     Maxvalue p1=new Maxvalue( );
     maxx=p1.maxvl(arr);
     System.out.println("max="+maxx);   
    }
  }

