﻿package ch3;
import java.applet.Applet;
import java.awt.Graphics;
public class  C3_6  extends Applet 
{
    @Override
   public void paint(Graphics g)
   {
    int k;
    int grade=86;
    k=grade/10;
    switch(k) {
      case 10:
      case 9:
        g.drawString("成绩:优",25,25);  break;
      case 8:
      case 7:
        g.drawString("成绩:良",25,25);  break;
      case 6:
        g.drawString("成绩:及格。",25,25);  break;
      default:  g.drawString("成绩:不及格。",25,25);
    }
  }
}

