﻿package ch3;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class C3_15
{ public static void main(String[ ] args) throws  IOException
  {
   BufferedReader keyin=new BufferedReader(new InputStreamReader(System.in));
   //上面一条语句是有关键盘输入数据流的处理，字符在各对象之间的流动过程如图3.12所示
    int Ltotal=0,Wtotal=0,Ztotal=0;
    char name;
    String c1;
    System.out.print("enter letter L or W or Z name, # to end:");
    c1=keyin.readLine( );	//从键盘上读取一个字符串赋给c1
    name=c1.charAt(0);	// charAt(0)是从一个字符串中截取第0个字符的方法
    while(name!='#')
    { 
        switch(name)
        {  
          case 'L':
          case 'l':  	//李姓人的得票, 列出两个case分别处理大、小写字母
              Ltotal=Ltotal+1; break;
          case 'W':
          case 'w':	//王姓人的得票
             Wtotal=Wtotal+1; break;
          case 'Z':
          case 'z': 	//张姓人的得票
             Ztotal=Ztotal+1; break;
        }   //switch语句结束
       System.out.print("enter letter L or W or Z name ,# to end:");
       c1=keyin.readLine( );
       name=c1.charAt(0);
     }	//while循环结束
     System.out.println(" Ltotal="+Ltotal);
     System.out.println(" Wtotal="+Wtotal);
     System.out.println(" Ztotal="+Ztotal);
   }
}

