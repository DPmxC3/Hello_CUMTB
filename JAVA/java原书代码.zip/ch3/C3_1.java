﻿package ch3;
public class C3_1 {
  public static void main(String[] args) {
    int grade;
    grade=86;  //读者在调试时也可赋一个小于60的成绩试试看
/* 此处最好使用一个数据输入语句，但Java从键盘读取整数或浮点数时要使用类、对象、
方法等知识。限于我们目前所学，此处用了一个赋值语句，待读者学习了第4章后，可
对该程序进行相应的修改，使其适应于各种情况 */
    if(grade>=60)
    {
      System.out.print("通过，成绩是：");
      System.out.println(grade);
    }
    else
      System.out.println("不及格");
 
    }
}
