package ch3;
public class C3_20 {
  public static void main(String[] args) {
      int j;
       p1: for(int i=1;i<=10;i++)
            {  j=1;
             while(j<=11-i)
             {  System.out.print(" ");  j++;  }
             for(j=1;j<=i;j++)
             {  if(i==3) continue; 		//当i＝3时，不论j为何值， 
                               		//均不执行后面的两条语句
                if(j==9) continue p1; 	//当j＝9时，跳到外循环入口处
                System.out.print(+i+"  ");
             }
            System.out.println(" ");
         }
   }
}
