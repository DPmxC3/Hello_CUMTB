﻿package ch3;
public class C3_11 {
  public static void main(String[] args) {
   int f1=1, f2=1;  //f1为第一项，即奇位项；f2为第二项，即偶位项
      for( int  i=1;  i<38/2;  i++)
      {
          System.out.print("\t"+f1+"\t"+f2);   //每次输出两项
          if(i%2==0)System.out.println("\n");  //每输出两次共4项后换行
          f1=f1+f2;   //计算下一个奇位项
          f2=f2+f1;   //计算下一个偶位项
       }
   }
}
