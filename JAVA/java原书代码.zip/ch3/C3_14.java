﻿package ch3;
public class C3_14 {
  public static void main(String[] args) {
    int i,sum;
     //下面的for循环中省略了判定表达式，其余位置使用了逗号运算符
       for(i=1,sum=0;  ; i++,sum+=i)
          if(i>10)break;  //循环体改成了判定跳转语句
      System.out.println("sum="+sum);

   }
}
