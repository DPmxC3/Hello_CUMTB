package ch3;
public class C3_18 {
  public static void main(String[] args) {
     int n=0,m,j,i;
    for(i=3;i<=100;i+=2)           	//外层循环
    { m=(int)Math.sqrt((double)i); 
      for(j=2;j<=m;j++)           	//内嵌循环
        if((i%j)==0)  break;      	//内嵌循环结束
      if(j>=m+1)
       {
         if(n%6==0)System.out.println("\n"); //换行控制
         System.out.print(i+"  ");  n++;
       }
     }   //外层循环结束
 }
}
