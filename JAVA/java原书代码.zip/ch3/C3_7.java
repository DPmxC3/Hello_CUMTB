package ch3;
public class C3_7 {
  public static void main(String[] args) {
    int x,y,z,a,b;
       a=1;
       b=2;
       x=(a>b) ? a : b;
       y=(a!=b) ? a : b;
       z=(a<b) ? a : b;
       System.out.print("\tx="+x);
       System.out.print("\ty="+y);
       System.out.println("\tz="+z);

   }
}
