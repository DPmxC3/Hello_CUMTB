package ch3;
public class C3_19 {
  public static void main(String[] args) {
    int n=0,m,j,i;
  p1: for(i=3;i<=100;i+=2)        	//外层循环，前面有标号p1
       { m=(int)Math.sqrt((double)i); 
         for(j=2;j<=m;j++)        	//内嵌循环
          { if((i%j)==0)break;
            if(i==51)break p1;  	//条件成立时结束由标号p1所指明的循环
          }   //内嵌循环结束
         if(j>=m+1)
           {  if(n%6==0) System.out.println("\n");
              System.out.print(i+"  ");  n++;
           }
        }   //外循环结束
   }
}
