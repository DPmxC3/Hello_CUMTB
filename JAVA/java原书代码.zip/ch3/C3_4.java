﻿package ch3;
public class C3_4 {
  public static void main(String[] args) {
    int grade=76;
     if(grade>=90)System.out.println("成绩:优");
     else if(grade>=80)System.out.println("成绩:良");
          else if(grade>=70)System.out.println("成绩:中等");
               else if(grade>=60)System.out.println("成绩:及格");
                    else System.out.println("成绩:不及格");
   }
}
