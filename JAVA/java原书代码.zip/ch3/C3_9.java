﻿package ch3;
import java.applet.Applet;
import java.awt.Graphics;
public class  C3_9  extends Applet 
{
    @Override
   public void paint(Graphics g)
   {
    int n=0;
      int sum=0;   //循环变量及其初始值
      do{
            n++; 
            sum+=n; //循环变量增值
         }while(sum<=100);  //循环条件
      g.drawString("sum="+sum,25,25);
      g.drawString("n="+n,100,25);
  }
}

