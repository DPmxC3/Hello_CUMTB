﻿package ch3;
public class C3_12 {
  public static void main(String[] args) {
        int i=1;  //初值表达式写在循环语句之前
        int sum=0;
        for(;;)   //for头的三个构件全部省略
        {   sum +=i++;  //循环过程表达式i++写在了循环体内
            if(i>10) break; //布尔表达式写在了循环体内的if语句中
        }
        System.out.println("sum="+sum);

   }
}
