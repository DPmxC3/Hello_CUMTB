﻿package ch3;
public class C3_3 {
  public static void main(String[] args) {
    int grade;
    grade=56; //读者在调试时也可赋一个等于或大于60的成绩试试看
    if(grade<60)
    { System.out.print("未通过，成绩是：");
      System.out.println(grade);
    }
   }
}
