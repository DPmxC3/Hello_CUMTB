﻿package ch3;
public class C3_5 {
  public static void main(String[] args) {
   int x,y;
    x=3;y=14;
    if(x>6)
       if(y>6)
            System.out.println("设备正常");
    else
      System.out.println("设备出错");

   }
}
