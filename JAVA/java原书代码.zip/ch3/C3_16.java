﻿package ch3;
public class C3_16 {
  public static void main(String[] args) {
    for(int i=1;i<=10;i++)        	//外层for循环
      {  for(int j=1;j<=11-i;j++)   	//内嵌for循环
            System.out.print(" ");  	//内嵌for循环的循环体
         for(int j=1;j<=i;j++)      	//并列的内嵌for循环
         {  if(i>=10)   System.out.print(+i+" ");
            else        System.out.print(+i+"  ");
          }                         //并列的内嵌for循环结束
          System.out.println(" ");
      }   
   }
}
