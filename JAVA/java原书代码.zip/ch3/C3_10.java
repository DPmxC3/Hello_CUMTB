package ch3;
public class C3_10 {
  public static void main(String[] args) {
   int sum=0,odd;
      for(odd=1;odd<=100;odd+=2)
        {  sum +=odd;  }
      System.out.println("sum="+sum+"   odd="+odd);
   }
}
