package ch3;
import java.applet.Applet;
import java.awt.Graphics;
public class  C3_2  extends Applet 
{
    @Override
   public void paint(Graphics g)
   {
    double d1=43.4; 
    double d2=85.3;
    if(d1>=d2)
       g.drawString(d1+" >= "+d2,25,25);
    else 
       g.drawString(d1+" < "+d2,25,25);
}
}

