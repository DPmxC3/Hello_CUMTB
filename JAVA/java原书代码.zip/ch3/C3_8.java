﻿package ch3;
public class C3_8 {
  public static void main(String[] args) {
   int counter=1;  //循环变量及其初始值
      while(counter<=5)  //循环条件
      {  System.out.println("counter="+counter);
         counter++;  //循环变量增值
      }

   }
}
