﻿package ch3;
public class C3_13 {
  public static void main(String[] args) {
    int i,sum;
    for(i=1,sum=0;i<=10;i++)  //初值表达式中使用了逗号运算符
      sum+=i;
    System.out.println("sum="+sum);

   }
}
