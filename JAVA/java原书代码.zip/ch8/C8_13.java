package ch8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
public class C8_13 {
  public static void main(String[] args) {  
     List<String> all = new ArrayList<String>();
     Collections.addAll(all,"B","E","A"); //增加内容
     Collections.addAll(all,"D","C"); 
     Iterator<String> iter = all.iterator();
        while (iter.hasNext()) //迭代输出  
           { System.out.print(iter.next() + "、"); }           
    }
}
