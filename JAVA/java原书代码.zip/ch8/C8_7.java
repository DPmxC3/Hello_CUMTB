package ch8;
import java.util.HashSet;
import java.util.Set;
public class C8_7 {
   public static void main(String[] args)
    {
        Set<String> set1 = new HashSet<String>();
        Set<String> set2 = new HashSet<String>();
        Set<String> set3 = new HashSet<String>();
        set1.add("Sa");    set1.add("Mi");
        set1.add("Ji");    set1.add("Vi");
        set3.add("Sa");    set3.add("Mi");  set3.add("Ti");
        set2.addAll(set1);  //将set1元素全部添加到set2中
        System.out.println("set1 = " + set1);
        System.out.println("set2 = " + set2); 
        System.out.println("set3 = " + set3); 
        set1.add("Cu");   set1.add("Po");
        System.out.println("添加元素后的 set1 = " + set1);
        System.out.println("判断set2是否是set1的子集:"+set1.containsAll(set2));
        set3.removeAll(set2); //将set3转换为ste3和set2的差集
        System.out.println("将set3转换为ste3和set2的差集:"+set3);
        set3.addAll(set2); //将set3转换为ste3和set2的并集
        System.out.println("将set3转换为ste3和set2的并集:"+set3);
        set3.retainAll(set2); //将set3转换为ste3和set2的交集
        System.out.println("将set3转换为ste3和set2的交集:"+set3);         
    }
}

