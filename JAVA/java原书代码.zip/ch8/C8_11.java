package ch8;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
public class C8_11 {
  public static void main(String[] args) {  
     Map<String, String> map  = new HashMap<String, String>();  
     map.put("书","Java");        
     map.put("学生","张丽"); 
     map.put("班级","201201"); 
     //将Map接口转换为Set接口 
     Set<Map.Entry<String,String>> allSet=map.entrySet(); 
     Iterator<Map.Entry<String,String>> iter = allSet.iterator();
     while (iter.hasNext()) {  
        Map.Entry<String,String> me = iter.next();   
        System.out.println(me.getKey()+" - " + me.getValue());  
     }
  }  
}
