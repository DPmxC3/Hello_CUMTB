package ch8;
import java.util.*;
public class C8_9 {
  public static void main(String[] args)
    { 
        SortedSet<String> set1 = new  TreeSet<String>();
        String[] str={"B","A","C","D"};
        Collection<String> list = new ArrayList<String>(Arrays.asList(str) );      
        set1.addAll(list);  //将s1元素全部添加到s2中
        System.out.println(" set1 = " + set1);        
        System.out.println(" headSet('C') = " + set1.headSet("C")); 
        System.out.println(" subSet('B','D') = " + set1.subSet("B","D"));
        System.out.println(" first() = " + set1.first());  
        System.out.println(" last() = " + set1.last());   
     } 
}
