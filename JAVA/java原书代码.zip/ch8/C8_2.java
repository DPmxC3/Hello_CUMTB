package ch8;
import java.util.ArrayList;
import java.util.List;
public class C8_2 {
    public static void main(String[] args) {
       //创建ArrayList，并转型为List
       List <String> cl = new ArrayList<String>( );
       cl.add("A1"); 
       cl.add("B2"); 
       cl.add("C3");
       System.out.println("输出集合的所有元素"+cl); 
       cl.add(1,"f1"); //下标1的位置插入一个元素
       System.out.println("元素下标1的位置插入f1后，输出所有元素"+cl); 
       String  b="B2";
       int n=cl.indexOf(b); //查找指定元素的下标
       cl.remove(n); //删除指定下标的元素
       System.out.println("n="+n+"   删除n元素后输出集合中所有元素");
       for(int i=0;i<cl.size();i++){ System.out.print(cl.get(i)+" , "); }  
       System.out.println();
    }
}

