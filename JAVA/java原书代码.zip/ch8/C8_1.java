package ch8;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
public class C8_1 {
    public static void main(String[] args) {
       Character[] c ={ 'A','B','C','D','E'}; //创建元素为字符对象引用的c数组
       System.out.print("输出元素为字符对象的c数组");
       for(int i=0;i<c.length;i++){ System.out.print(c[i]+" , "); } 
       System.out.println();
       //创建ArrayList，并转型为Collection
       //Arrays.asList(c)表示c数组的元素是ArrayList的元素
       Collection<Character> cl = new ArrayList<Character>(Arrays.asList(c) );
       cl.add((Character)'f'); //添加一个元素
       System.out.println("输出集合中添加f后的所有元素"+cl); 
       cl.remove((Character)'B'); //删除一个元素
       System.out.println("用迭代器输出集合中删除B后的所有元素");
       Iterator<Character> it = cl.iterator();
       while( it.hasNext()) {
            Character i = it.next();
            System.out.print(i+" , ");
        }
       System.out.println();
       Object[] cc= cl.toArray();
       System.out.print("输出集合转数组后数组的所有元素: ");
       for(int i=0;i<c.length;i++){ System.out.print(cc[i]+" , "); }  
       System.out.println();
    }
}
