package ch8;
import java.util.ArrayList;
public class C8_3 {
   public static void main(String[] args) {
       //创建ArrayList
       ArrayList <Integer> nl = new ArrayList<Integer>( );
       nl.add((Integer)1); 
       nl.add((Integer)2); 
       nl.add((Integer)3);
       System.out.println("输出集合的所有元素"+nl); 
       System.out.println("输出下标为2的元素: "+nl.get(2)); 
       nl.add(1,(Integer)4); //下标1的位置插入一个元素
       System.out.println("元素下标1的位置插入f后，输出所有元素"+nl); 
       Integer b=(Integer)1;
       int n=nl.indexOf(b); //查找指定元素的下标
       nl.remove(n); //删除指定下标的元素
       System.out.println("n="+n+"   删除n元素后输出集合中所有元素");
       for(Integer i : nl){ System.out.print(i+" , "); }  
       System.out.println();
    }
}
