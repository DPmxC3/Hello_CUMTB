package ch8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
public class C8_14 {
     public static void main(String[] args) {  
     List<String> all = new ArrayList<String>();
     Collections.addAll(all,"B","E","A","D","C");
     System.out.print("排序之前的集合：");
     Iterator<String> iter = all.iterator();
     while (iter.hasNext()) 
       { System.out.print(iter.next() + "、");  }  
     Collections.sort(all); //集合排序
     System.out.print("\nsort()方法排序后的集合：");
     iter = all.iterator();
     while (iter.hasNext())
       {  System.out.print(iter.next() + "、"); } 
     Collections.reverse(all); //集合反序
     System.out.print("\nreverse()方法排序后的集合：");
     iter = all.iterator();
     while (iter.hasNext())
       {  System.out.print(iter.next() + "、"); } 
   }
}
