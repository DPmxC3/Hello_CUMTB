package ch8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class C8_15 {
   public static void main(String[] args) {  
    int[] ar={11,12,13,56,3}; 
    List<Integer> list = new ArrayList<Integer>();
    for(int i=0;i<ar.length;i++) list.add(new Integer(ar[i]));
    System.out.println("混排之前的集合："+list);
    Collections.shuffle(list); //混排算法
    System.out.println("混排之后的集合："+list);
   }     
}
