package ch8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class C8_17 {
     public static void main(String[] args) {  
      List<String> all = new ArrayList<String>();     
      Collections.addAll(all,"A1","B1","C1");
      System.out.println("集合结果："+all);
      int n=Collections.binarySearch(all,"C1"); //二分搜索算法 
      System.out.println("检索到“C1”，返回它的下标="+n);
      int n1=Collections.binarySearch(all,"11"); //二分搜索算法 
      System.out.println("检索不到“11”，返回它值="+n1);
      int n2=Collections.binarySearch(all,"pp"); //二分搜索算法 
      System.out.println("检索不到“pp”，返回它值="+n2);
   }
}
