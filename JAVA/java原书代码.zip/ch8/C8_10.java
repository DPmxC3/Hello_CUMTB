package ch8;
import java.util.*;
public class C8_10 {
    public static void main(String[] args) {  
       Map<String, String> map  = new HashMap<String, String>();  
       map.put("书","Java");        
       map.put("学生","张丽"); 
       map.put("班级","201201"); 
       System.out.println("map=:" +map.toString()); //输出Map
       if (map.containsKey("书")) //查找Key=书是否存在 
       {  
         System.out.print("查找Key=书 存在  ");  
         String val = map.get("书");  //根据key求出 value
         System.out.println("书=" + val);     
       }
       else {  System.out.println("查找Key=书 不存在");  } 
       //全部输出Key
       Set<String> keys = map.keySet();  //得到全部的key
       Iterator<String> iter1 = keys.iterator();
       System.out.print("全部的key：");
        while (iter1.hasNext()) {
          String str = iter1.next();   
          System.out.print(str + "、");  
        }
        Collection<String> values = map.values();  //得到全部的value 
        Iterator<String> iter2 = values.iterator();
        System.out.print("\n全部的value：");
        while (iter2.hasNext()) {
          String str = iter2.next();
          System.out.print(str + "、"); 
        } 
        System.out.println( );
  }  
}
