package ch8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class C8_18 {
  public static void main(String[] args) {  
    List<String> all = new ArrayList<String>();
    Collections.addAll(all, "AA", "DD", "BB");  
    System.out.println("交换之前的集合："+all);  
    Collections.swap(all,0,2) ;  //交换指定位置算法
    System.out.println("交换之后的集合："+all); 
   } 
}
