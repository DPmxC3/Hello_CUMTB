package ch8;
import java.util.LinkedList;
public class C8_5 extends LinkedList
{
   public static void main(String[] args)
   { 
      C8_5 queue=new C8_5(); 
      queue.addLast("a11"); //入队操作
      queue.addLast("a22"); 
      queue.addLast("a33"); 
      System.out.println(queue.removeFirst());  //出队操作
      System.out.println(queue.getFirst()); //取对头元素操作
      System.out.println(queue.removeFirst()); 
      System.out.println(queue.isEmpty()); //判断队空操作
  } 
}

