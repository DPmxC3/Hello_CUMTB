package ch8;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
public class C8_16 {
   public static void main(String[] args) {  
      List<String> all = new ArrayList<String>();     
      Collections.addAll(all,"A1","B1","C1");
      System.out.println("替换之前的结果："+all);
      if(Collections.replaceAll(all, "B1","DD")) //替换内容 
         System.out.println("替换之后的结果："+all);
   }
}
