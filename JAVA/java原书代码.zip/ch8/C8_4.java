package ch8;
import java.util.LinkedList; 
public class C8_4 extends LinkedList
{ 
  public static void main(String[] args)
  { 
    C8_4 stack=new C8_4(); 
    stack.push("a1"); //入栈操作
    stack.push("a2"); 
    stack.push("a3");     
    System.out.println(stack.pop());  //出栈操作
    System.out.println(stack.peek()); //取栈顶元素操作
    System.out.println(stack.pop());  //出栈操作
    System.out.println(stack.isEmpty()); //判断栈空操作
  } 
} 