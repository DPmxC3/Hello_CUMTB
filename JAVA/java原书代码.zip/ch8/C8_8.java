package ch8;
import java.util.*;
public class C8_8 {
    public static void main(String[] args)
    {
        LinkedHashSet<String> s1 = new LinkedHashSet<String>();
        HashSet<String> s2 = new  HashSet<String>();
        TreeSet<String> s3 = new  TreeSet<String>();
        String[] str={"B","A","C","D"};
        Collection<String> list = new ArrayList<String>(Arrays.asList(str) );      
        s1.addAll(list);  //将s1元素全部添加到s2中
        s2.addAll(list);  //将s1元素全部添加到s2中
        s3.addAll(list);  //将s1元素全部添加到s2中
        System.out.println(" s1 = " + s1);
        System.out.println(" s2 = " + s2);  
        System.out.println(" s3 = " + s3);   
    } 
}
