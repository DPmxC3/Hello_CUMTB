package ch15;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
public class C15_2 
{ 
   public static void main(String[] args)
  { 
     
     String Str;   InputStream st1;
     //String ur="http://netbeans.org/kb/docs/java/quickstart.html"; //获取远程网上的信息
     String ur="file:///E:/Java/ch15/src/ch15/C15_1.java";  //获取本地网上的信息
     try 
      { 
        URL MyURL=new URL(ur); 
        st1=MyURL.openStream();  
        InputStreamReader ins=new InputStreamReader(st1); 
        BufferedReader in=new  BufferedReader(ins);
        while((Str=in.readLine())!= null)  //从URL处获取信息并显示
          {  System.out.println(Str); } 
       } 
     catch(MalformedURLException e)  //创建URL对象可能产生的异常
       {  System.out.println("Can't get URL: " ); } 
     catch (IOException e)
       {  System.out.println("Error in I/O:" + e.getMessage());  } 
   } 
}
