package ch15;
//Socket客户端程序
import java.io.*;
import java.net.InetAddress;
import java.net.Socket;
public class C15_6
{ 
 public static void main(String[ ] args)
 { String str;
   try{ 
     InetAddress addr=InetAddress.getByName("127.0.0.1");
     //InetAddress addr=InetAddress.getByName("198.198.1.68");
     Socket socket=new Socket(addr,8000); 
     System.out.println("Socket: "+socket); 
    //获得对应socket的输入/输出流 
     InputStream fIn=socket.getInputStream( ); 
     OutputStream fOut=socket.getOutputStream( ); 
   //建立数据流 
     InputStreamReader isr=new InputStreamReader(fIn); 
     BufferedReader in=new BufferedReader(isr);   
     PrintStream out=new PrintStream(fOut); 
     InputStreamReader userisr=new InputStreamReader(System.in); 
     BufferedReader userin=new BufferedReader(userisr);   
     while(true){ 
       System.out.print("发送字符串:"); 
       str=userin.readLine( );  //读取用户输入的字符串
       out.println(str);  //将字符串传给服务器端
       if(str.equals("end"))break;  //如果是"end"，就退出
       System.out.println("等待服务器端消息..."); 
       str=in.readLine( );  //获取服务器获得字符串
       System.out.println("服务器端字符:"+str); 
       if(str.equals("end"))break;
      } 
     socket.close( );  //关闭连接 
    } 
   catch(Exception e)
     {   System.out.println("异常:"+e);  } 
  } 
}

