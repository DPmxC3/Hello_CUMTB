package ch15;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
class C15_3
{
  public static void main(String[] args)
   {
    try {
        String ur="http://www.chd.edu.cn";  //获取远程网上的信息
       // String ur="file:///E:/Java/ch15/src/ch15/C15_1.java" ;  //获取本地网上的信息
        URL MyURL=new URL(ur);
        String str;
        URLConnection con=MyURL.openConnection();
        InputStreamReader ins=new InputStreamReader(con.getInputStream());
        BufferedReader in=new  BufferedReader(ins);
        while ((str=in.readLine())!=null) {  System.out.println(str); }
        in.close();
       }
    catch (MalformedURLException mfURLe)
      { System.out.println("MalformedURLException: " + mfURLe);  }
    catch (IOException ioe)
      {  System.out.println("IOException: " + ioe);    }
   }
}
