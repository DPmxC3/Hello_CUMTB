package ch15;
import java.net.MalformedURLException;
import java.net.URL;
public class C15_1
{
  public static void main(String args[ ]) 
  {
    URL MyURL=null;
    try
      {  MyURL=new URL("http://netbeans.org/kb/docs/java/quickstart.html"); }
    catch (MalformedURLException e) 
      {  System.out.println("MalformedURLException: " + e);    }
    System.out.println("URL String: "+MyURL.toString( ));  //获取URL对象转换成字符串
    System.out.println("Protocol: "+MyURL.getProtocol( )); //获取协议名
    System.out.println("Host: "+MyURL.getHost( ));  //获取主机名
    System.out.println("Port: "+MyURL.getPort( ));  //获取端口号
    System.out.println("File: "+MyURL.getFile( ));  //获取文件名
  }
}
