﻿package ch4;
import java.applet.Applet;
import java.awt.Graphics;
class Dogs1  //定义Dogs1类
{
   public String name;
   public int weight;
   public int height;
   public Dogs1(String cName, int cWeight, int cHeight)   //构造方法
   {  name=cName;
      weight=cWeight;
      height=cHeight;
   } //构造方法定义
   public void ShowDog(Graphics g,int x,int y)
   {  g.drawString("Name:"+name,x,y);
     g.drawString("Weight:"+weight,x,y+20);
     g.drawString("Height:"+height,x,y+40);
   }
} // Dogs1类定义
public class C4_3  extends Applet
{
    @Override
   public  void paint(Graphics g)
   {  Dogs1 dane=new Dogs1("Gread Dane",100,23);
      Dogs1 setter=new Dogs1("Irish Setter",20,30);
      dane.ShowDog(g,25,25);
      setter.ShowDog(g,25,120);
   }
}
