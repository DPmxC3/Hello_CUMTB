package ch4;
public class C4_12
{
   static void add(double x,double y)
    {  double z;
       z=x+y;
       System.out.println("z="+z);
       x=x+3.2;y=y+1.2;
       System.out.println("x="+x+"\ty="+y);
    }
   static double add1(double y1,double y2)
    {  double z;
       z=y1+y2+2.9;
       return z;
    }
public static void main(String[ ] args)
    { int a=2,b=7;
      double f1=2,f2=4,f3;
      add(a,b);		// 按Java的类型转换规则达到形参类型
      System.out.println("a="+a+"\tb="+b);
      // f3=add1(f1, f2, 3.5)；错，实参与形参的参数个数不一致
      f3=2+add1(f1,f2);
      System.out.println("f1="+f1+"\tf2="+f2+"\tf3="+f3);
    }
 }
