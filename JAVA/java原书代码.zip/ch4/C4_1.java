package ch4;
import java.applet.Applet;
import java.awt.Graphics;
public class C4_1  extends  Applet  	//由applet类派生的c4_1类
{  int  a=5;          			//数据成员a
   double b=23.4;   				//数据成员b
    @Override
   public void paint(Graphics g)  	//成员方法paint
   {  //以下使用g对象的drawString方法
      g.drawString("a="+a,25,25); 
      g.drawString("b="+b,25,35);
   }
}

