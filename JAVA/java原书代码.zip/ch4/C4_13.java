package ch4;
public class C4_13
{
   static void add(double x,double y)
    {  double z;
       z=x+y;
       System.out.println("z="+z);
    }
   static double add1(double y1,double y2)
    {  double z;
       z=y1+y2+2.9;
       return z;
    }
   public static void main(String[ ] args)
    {  int a=2;
      double f1=2,f2=4;
      add(a,add1(f1,f2));
    }
 }
