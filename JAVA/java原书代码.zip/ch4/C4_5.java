﻿package ch4;
class  Pp 
{  C4_5  f1=new  C4_5( );   //在Pp类中创建C4_5类的对象
   int  add( )
   {  //下面的语句用引用变量f1访问C4_5类对象的数据成员b和c
      return(f1.b+f1.c); 
   }
}

public  class  C4_5     //定义公共类C4_5
{  int b=20,c=3;       //C4_5类的数据成员b和c
   public  static  void  main(String[ ] args)
   {  Pp  p1=new  Pp( );  //创建Pp类的对象
      System.out.println(p1.add( ));
    }
 }
