package ch4;
public class C4_11
{
   public static void main(String[ ] args)
    { int a=2,b=3;
      { int z=a+b;  //复合语句中声明的变量z
        System.out.println("z="+z);
      }
// System.out.println("z="+z); 错，z只在复合语句中有效
    }
}
