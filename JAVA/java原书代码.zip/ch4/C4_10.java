package ch4;
public class C4_10
{
  public static void main(String[ ] args)
    { int a=2,b=3;
      int f=add(a,b);  //调用add方法
      System.out.println("f="+f);
      //System.out.println("z="+z);错，z在add方法内，离开add则被清除
    }
   static int add(int x,int y)
    { //public int zz;	//错误的语句，在局部变量zz前误加了public修饰符
       int z,d;   	//本方法中定义的变量z和d
       z=x+y;    	//若写成 z=x+d;就会出错，因为d还没有被赋值就使用
       return z; 
    }
}
