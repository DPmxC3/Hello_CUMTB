﻿package ch4;
class  Pp1      //无修饰符的类Pp
{ 
  int  a=45;  //Pp类的数据成员a
 }

public class  C4_4  //公共类C4_4
{
   public static void main(String[ ] args)
    { Pp1  p1=new  Pp1( ); //类C4_4中创建了一个无修饰符类Pp的p1引用的对象
      System.out.println(p1.a);
    }
 }

