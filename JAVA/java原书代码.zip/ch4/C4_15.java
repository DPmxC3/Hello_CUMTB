package ch4;
public class C4_15
{   
    public static void main(String[ ] args)
    {  int n=8;   
       int f8=fibo(n);
       System.out.println("f8="+f8);    }
    static int fibo(int n)
    {  if(n==1)return 1;
       else if(n==2)return 1;  
            else return (fibo(n-1)+fibo(n-2));
    }
 }
