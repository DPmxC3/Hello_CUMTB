package ch4;
public class C4_14
{   static int fac(int n)
    { int fa;
      if(n==0)
        fa=1;
      else
        fa=n*fac(n-1);  	//递归引用自身
      return fa;
    }
  public static void main(String[ ] args)
    { int n=4;
      int f1=fac(n);  	//引用fac( )方法
      System.out.println("4!="+f1);
    }
 }
