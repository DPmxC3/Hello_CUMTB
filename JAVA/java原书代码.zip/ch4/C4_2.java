package ch4;
import java.applet.Applet;
import java.awt.Graphics;
class Dogs  //定义Dogs类
{
     //以下三行定义Dogs类的数据成员
   public  String  name;
   public  int  weight;
   public  int  height;
     //以下六行是Dogs类的成员方法showDog( )的定义
   public  void  showDog(Graphics g,int x,int y)
   {
     g.drawString("Name:"+name,x,y);
     g.drawString("Weight:"+weight,x,y+20);
     g.drawString("Height:"+height,x,y+40);
   } //成员方法showDog( )定义完成
}// Dogs类定义毕

public class C4_2  extends Applet
{
    @Override
   public  void paint(Graphics g)
   {
      //以下为创建对象
      Dogs dane;  //声明Dane为属于dogs类的引用对象的变量
      dane=new Dogs( );  //创建由dane引用的dogs对象
      Dogs setter=new Dogs( );// 创建由setter引用的dogs对象
      //以下六行是通过引用对象的变量将一组值赋给对象的数据成员
      dane.name="Gread Dane";
      dane.weight=100;  dane.height=23;
      setter.name="Irish Setter";
      setter.weight=20;  setter.height=30;
      //以下两行是通过引用对象的变量引用对象的成员方法
      dane.showDog(g,25,25);
      setter.showDog(g,25,120);
    }
 }
