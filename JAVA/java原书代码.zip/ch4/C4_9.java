package ch4;
import java.applet.Applet;
import java.awt.Graphics;
class Ca
{   static int n=20;
final int nn; 	//声明nn，但没有赋初值
    final int k=40;	//声明k并赋初值40
    Ca( )
    {  nn= ++n; }	//在构造方法中给nn赋值
}

public class C4_9 extends Applet
{
    @Override
    public void paint(Graphics g)
    {  Ca m1=new Ca( );  //创建Ca对象，使其静态数据成员nn的值为21
      Ca m2=new Ca( );   //创建Ca对象，使其静态数据成员nn的值为22
      // m1.nn=90; //这是一个错误的赋值语句，因为nn是标识符常量
      g.drawString("m2.nn="+m2.nn,20,30);
      g.drawString("m2.k="+m2.k,20,50);
      g.drawString("m1.nn="+m1.nn,20,70);
      g.drawString("m1.k="+m1.k,20,90);
     }
}
