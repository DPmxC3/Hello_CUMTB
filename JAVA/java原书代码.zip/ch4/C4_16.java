package ch4;
public class C4_16
{   public static void main(String[ ] args)
    {  double a=2,b=3;
      double z1=Math.pow(a,b);   //引用Math类的pow方法求a的b次方
      double z2=Math.sqrt(9);     //引用Math类的sqrt方法求9的平方根
      System.out.print("z1="+z1);
      System.out.println("\tz2="+z2);
   }
}
