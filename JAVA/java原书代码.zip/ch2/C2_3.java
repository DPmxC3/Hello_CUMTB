﻿package ch2;
public class C2_3 {
  public static void main(String args[ ])
   {  char  c1, c2, c3;   	//声明变量c1、c2、c3为字符型变量
       c1='H';           	//在以c1标识的存储单元中存入字符H
       c2='\\';           	//在以c2标识的存储单元中存入字符\
       c3='\115';        	 	//在c3中存入八进制数115代表的ASCII字符M
       System.out.print(c1);   	//输出字符型变量c1的值
       System.out.print(c2);   	//输出字符型变量c2的值
       System.out.print(c3);   	//输出字符型变量c3的值
   }  
}
