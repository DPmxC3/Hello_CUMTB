﻿package ch2;
public class C2_4 {
  public static void main(String args[ ])
   {   boolean  x, y, z;   		//声明变量x、y、z为布尔型变量
       int a=89, b=20;
       x=(a>b); //对布尔型变量赋值(这里涉及的关系运算请参阅表2.15)
       y=(a!=b);   				//对布尔型变量赋值
       z=(a+b==43);   //对布尔型变量赋值
       System.out.println("x="+x);  	//输出布尔型变量的值
       System.out.println("y="+y);  	//输出布尔型变量的值
       System.out.println("z="+z);  	//输出布尔型变量的值
   }  
}
