﻿package ch2;
public class C2_7 {
  public static void main(String args[ ])
   {   int x,y,z;
       x=1;
       y=2;   z=3;
       x+=y;   //等价于x=x+y;
       y%=x;  //等价于y=y%x;
       z/=x;   //等价于z=z/x;
       System.out.print("\tx="+(x+=y));
       System.out.print("\ty="+y);
       System.out.println("\tz="+z);
   }  
}
