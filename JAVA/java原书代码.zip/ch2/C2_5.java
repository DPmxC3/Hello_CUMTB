﻿package ch2;
public class C2_5 {
  public static void main(String args[ ])
   {   int x,y,z,a,b;
       a=9;
       b=2;
       x=a%b;
       y=2+ ++a;  //等价于a=a+1; y=2+a;
       z=7+ --b;
       System.out.print("\tx="+x);
       System.out.print("\ty="+y);
       System.out.println("\tz="+z);
   }  
}
