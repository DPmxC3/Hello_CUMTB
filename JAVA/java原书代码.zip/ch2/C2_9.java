package ch2;
public class C2_9 {
  public static void main(String args[ ])
   {  boolean x,y,z,a,b;
       a='b'>'N';
       b='A'!='A';
       x=(!a);
       y=(a&&b);
       z=(a&b);
       System.out.print("\ta="+a);
       System.out.print ("\tb="+b);
       System.out.print("\tx="+x);
       System.out.print("\ty="+y);
       System.out.println("\tz="+z);
   }  
}
