package ch2;
public class C2_8 {
  public static void main(String args[ ])
   {   boolean x,y;
       double a,b;
       a=12.897;
       b=345.6;
       x=(a!=b);
       y=(a==b);
       System.out.println("(a>b)="+(a>b));
       System.out.println("x="+x);
       System.out.println("y="+y);
   }  
}
