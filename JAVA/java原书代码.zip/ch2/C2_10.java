package ch2;
public class C2_10 {
  public static void main(String args[ ])
   {  
      int x,y,z,a,b;
       a=22;   b=3;
       x=a>>>b;
       y=a^b;
       z=~a;
       System.out.print("\ta&b="+(a&b));
       System.out.print("\ta|b="+(a|b));
       System.out.println("\ta<<b="+(a<<b));
       System.out.print("\ta>>b="+(a>>b));
       System.out.print("\tx="+x);
       System.out.print("\ty="+y);
       System.out.println("\tz="+z);
   }  
}
