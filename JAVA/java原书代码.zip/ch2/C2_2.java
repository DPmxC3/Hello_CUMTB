package ch2;
public class C2_2 {
  public static void main(String args[ ])
   {   float x,y,z;
       x=94.3f;     y=32.9f;    z=x/y;
       System.out.println(x+"/"+y+"="+z);
   }
  
}
