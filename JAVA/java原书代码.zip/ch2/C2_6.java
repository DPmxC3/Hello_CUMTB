﻿package ch2;
public class C2_6 {
  public static void main(String args[ ])
   {   int x,y;
       x=(int)82.5;
       y=(int)'A'+(int)'b';  //等价于65+98
       System.out.print("\tx="+x);
       System.out.println("\ty="+y);
   }  
}
