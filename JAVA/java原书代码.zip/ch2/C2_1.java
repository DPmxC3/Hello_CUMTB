﻿package ch2;
public class C2_1 {
    public static void main(String[] args) {
    {   byte  a1=071;  	//八进制数
        byte  a2=10;   	//十进制数
        byte  a3=0x21;  	//十六进制数
        int   b1,b2,i1=4;
        short  c1=0x1E2;
        long  d=0x10EF,d1=1234567;
        b1=b2=15; 
        System.out.println("sum="+(1+5));
        System.out.print("a1=0"+Integer.toOctalString(a1)+"(八进制输出) ");
        System.out.print("\ta1="+a1); //按十进制值输出
        System.out.print("\ta2="+a2);       
        System.out.print("\ta3=0x"+Integer.toHexString(a3)+"(十六进制输出)");  
        System.out.println("\ta3="+a3); //按十进制值输出
        System.out.print("i1="+Integer.toBinaryString(i1)+"(二进制输出)");
        System.out.print("\ti1="+i1);
        System.out.print("\tb1="+b1);
        System.out.println("\tb2="+b2);       
        System.out.format("c1=0x"+ "%x ", c1);      
        System.out.print("\tc1="+c1); //按十进制值输出
        System.out.print("\td="+d);   //按十进制值输出     
        System.out.print("\td1="+d1);
       }

    }
}
