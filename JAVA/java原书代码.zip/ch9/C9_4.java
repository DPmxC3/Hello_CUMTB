package ch9;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JApplet;
public  class C9_4 extends JApplet
{  
   Font f=new Font("Courier", Font.ITALIC+Font.BOLD,24);  //������ʽ��б�Ӵ�
    @Override
   public void paint(Graphics g) 
    { Graphics2D g2=(Graphics2D)g;  
      int style,size;
      String s,name;
      g2.setFont(f);
      style=f.getStyle();  //�õ�������ʽ
      if (style ==Font.PLAIN)    s="Plain";
      else if (style ==Font.BOLD)   s="Bold";
      else if (style ==Font.ITALIC)  s="Italic";
      else     s="Bold italic";
      size=f.getSize();  //�õ������С
      s+=size+"point";
      name=f.getName();  //�õ���������
      s+=name;
      g2.drawString(s,10,50);
     }
 }

