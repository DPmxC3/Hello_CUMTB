package ch9;
import java.awt.Graphics;
import javax.swing.JApplet;
public class C9_1 extends JApplet
{   
    private String s = "WELCOME!";
    private char c[] = {'T','O','a','e','t'};
    private byte b[] = {'d','4','X','I','\047','A','N'};
    @Override
    public void paint( Graphics g)  //����Applet�ĳ�Ա����
     { g.drawString( s, 50, 25);
       g.drawChars( c, 0, 2, 50, 50);
       g.drawBytes( b, 2, 5, 50, 75);
     }
 }  
