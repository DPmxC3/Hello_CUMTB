package ch9;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Arc2D;
import java.awt.geom.Ellipse2D;
import javax.swing.JApplet;
public class C9_8 extends  JApplet
 {  @Override
  public void paint(Graphics g) 
    { Graphics2D g2=(Graphics2D)g;
      g2.setPaint(Color.red);  //����ǰ����ɫ
      g2.setStroke(new BasicStroke(2));//�����߿�
      // ���ƻ�
      g2.draw(new Arc2D.Double(15,15,80,80,60,125,Arc2D.OPEN));
      g2.draw(new Arc2D.Double(100,15,80,80,60,125,Arc2D.CHORD));
      g2.draw(new Arc2D.Double(200,15,80,80,60,125,Arc2D.PIE));
      g2.fill(new Arc2D.Double(280,15,80,80,60,125,Arc2D.OPEN));
      g2.drawString("Arc2D",100,90);
      // ����Բ����Բ   
      g2.drawString("Ellipse2D",100,220);
      g2.setPaint(Color.lightGray); 
      Ellipse2D.Double e1=new Ellipse2D.Double(15,120,100,50); 
      Ellipse2D.Double e2=new Ellipse2D.Double(150,120,80,80); 
      g2.fill(e2);     g2.setPaint(Color.black); 
      g2.setStroke(new BasicStroke(6));
      g2.drawString("Ellipse2D",100,220); 
      g2.draw(e1);   g2.draw(e2); 
    }
 }

