package ch9;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import javax.swing.JApplet;
public class C9_7 extends  JApplet
 {
    @Override
   public void paint(Graphics g) 
    { Graphics2D g2=(Graphics2D)g;
      g2.setPaint(Color.red);  //����ǰ����ɫ
      // draw Rectangle2D.Double  
      Rectangle2D.Double rec=new Rectangle2D.Double(20,20,60,30); //�������ζ���
      g2.draw(rec);     g2.drawString("Rectangle2D",20,70);
      // draw  RoundRectangle2D.Double
      g2.setStroke(new BasicStroke(4));//�����߿�
      g2.draw(new RoundRectangle2D.Double(100,20,60,30,10,10)); ///����Բ�Ǿ��ζ��󲢻���
      g2.drawString("RoundRectangle2D",100,70);
      g2.setPaint(Color.blue);  //����ǰ����ɫ
      // fill Rectangle2D.Double
       Rectangle2D.Double rec1=new Rectangle2D.Double(20,80,60,30);
      g2.fill(rec1);    g2.drawString("Rectangle2D",20,120);
      // fill  RoundRectangle2D.Double
      g2.setStroke(new BasicStroke(4));//�����߿�
      RoundRectangle2D.Double rorec=new RoundRectangle2D.Double(100,80,60,30,10,10);
      g2.fill(rorec);    g2.drawString("RoundRectangle2D",100,120); 
   }
 }

