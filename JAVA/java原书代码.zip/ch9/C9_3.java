package ch9;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JApplet;
public class C9_3 extends JApplet
{  Font f1 = new Font("TimesRoman",Font.BOLD,16);  //����ΪTimesRoman��������ʽ�Ӵ�
   Font f2 = new Font("Courir",Font.ITALIC,24);    //����ΪCourir��������ʽ��б
   Font f3 = new Font("Helvetica",Font.PLAIN,14);  //����
   String hStr = "Courir";
    @Override
   public void paint(Graphics g) 
    {
       Graphics2D g2=(Graphics2D)g;  
       g2.setFont(f1); 
       g2.drawString("TimesRoman",20,50); 
       g2.setFont(f2); 
       g2.drawString(hStr,20,100); 
       g2.setFont(f3); 
       g2.drawString("Helvetica",20,150); 
    }
 }

